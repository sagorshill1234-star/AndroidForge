<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="24dp">

    <TextView
        android:id="@+id/tvTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Flashlight Brightness Controller"
        android:textSize="20sp"
        android:textStyle="bold" />

    <androidx.appcompat.widget.SwitchCompat
        android:id="@+id/switchFlashlight"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="30dp"
        android:text="Flashlight Status "
        android:textSize="18sp" />

    <TextView
        android:id="@+id/tvBrightness"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="40dp"
        android:text="Brightness: Level 1"
        android:textSize="16sp" />

    <SeekBar
        android:id="@+id/seekBarBrightness"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:max="5"
        android:progress="1" />

</LinearLayout>

