package com.miniphone.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView output;
    private EditText input;
    private TextToSpeech tts;
    private static final int REQ_SPEECH = 101;
    private static final int REQ_MIC = 102;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn", "BD"));
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
        say("স্বাগতম। আমি MINI PHONE AI। নিচের মাইক্রোফোন বোতাম চাপুন অথবা লিখে নির্দেশ দিন।");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("MINI PHONE AI");
        title.setTextSize(27);
        title.setTextColor(0xFF55DDE0);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Personal voice assistant • বাংলা / English");
        subtitle.setTextColor(0xFFFFFFFF);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 20);
        root.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextColor(0xFFFFFFFF);
        output.setTextSize(17);
        output.setText("এখানে উত্তর দেখা যাবে।\\n");
        output.setPadding(14, 14, 14, 14);
        scroll.addView(output);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        input = new EditText(this);
        input.setSingleLine(false);
        input.setHint("এখানে নির্দেশ লিখুন…");
        input.setTextColor(0xFFFFFFFF);
        input.setHintTextColor(0xFFB0BEC5);
        root.addView(input, new LinearLayout.LayoutParams(-1, -2));

        Button voice = new Button(this);
        voice.setText("🎙 কথা বলুন");
        voice.setOnClickListener(v -> startVoice());
        root.addView(voice, new LinearLayout.LayoutParams(-1, -2));

        Button run = new Button(this);
        run.setText("নির্দেশ চালান");
        run.setOnClickListener(v -> handleCommand(input.getText().toString().trim()));
        root.addView(run, new LinearLayout.LayoutParams(-1, -2));

        Button help = new Button(this);
        help.setText("কী কী বলতে পারি?");
        help.setOnClickListener(v -> reply("বলতে পারেন: সময় কত, সেটিংস খোলো, Wi-Fi সেটিংস খোলো, Bluetooth খোলো, YouTube খোলো, Google-এ খোঁজো [বিষয়], কাউকে মেসেজ লিখে দাও [নম্বর], [নম্বর]-এ কল করো।"));
        root.addView(help, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার নির্দেশ বলুন");
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            reply("এই ফোনে Speech Recognition সেবা পাওয়া যায়নি। কিবোর্ডে নির্দেশ লিখে চেষ্টা করুন।");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                handleCommand(results.get(0));
            }
        }
    }

    private void handleCommand(String raw) {
        if (raw == null || raw.trim().isEmpty()) { reply("একটি নির্দেশ বলুন বা লিখুন।"); return; }
        String c = raw.toLowerCase(Locale.ROOT).trim();
        output.append("\\nআপনি: " + raw + "\\n");

        if (c.contains("সময়") || c.contains("time")) {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault());
            reply("এখন সময় " + f.format(new java.util.Date()));
        } else if (c.contains("সেটিংস") || c.contains("settings")) {
            openSettings();
        } else if (c.contains("wi-fi") || c.contains("wifi") || c.contains("ওয়াইফাই")) {
            launch(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS), "Wi-Fi সেটিংস খুলতে পারিনি।");
        } else if (c.contains("bluetooth") || c.contains("ব্লুটুথ")) {
            launch(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth সেটিংস খুলতে পারিনি।");
        } else if (c.contains("youtube")) {
            openAppOrSearch("com.google.android.youtube", "YouTube");
        } else if (c.contains("ক্যামেরা") || c.contains("camera")) {
            launch(new Intent("android.media.action.IMAGE_CAPTURE"), "ক্যামেরা খোলা যায়নি।");
        } else if (c.contains("মেসেজ") || c.contains("sms") || c.contains("message")) {
            String digits = raw.replaceAll("[^0-9+]", "");
            if (digits.length() >= 6) {
                Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + digits));
                sms.putExtra("sms_body", "");
                launch(sms, "মেসেজ অ্যাপ খোলা যায়নি।");
                reply("মেসেজ অ্যাপ খুলেছি। লেখা দেখে নিজে পাঠিয়ে দিন।");
            } else {
                reply("মেসেজ পাঠাতে নম্বরসহ লিখুন, যেমন: মেসেজ 01XXXXXXXXX। নিরাপত্তার জন্য পাঠানোর আগে মেসেজ অ্যাপে যাচাই করুন।");
            }
        } else if (c.contains("কল কর") || c.contains("call ")) {
            String digits = raw.replaceAll("[^0-9+]", "");
            if (digits.length() >= 6) {
                Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits));
                launch(dial, "ডায়ালার খোলা যায়নি।");
                reply("ডায়ালার খুলেছি। নম্বর যাচাই করে কল বোতাম চাপুন।");
            } else reply("কল করতে নম্বরসহ বলুন, যেমন: 01XXXXXXXXX নম্বরে কল করো।");
        } else if (c.contains("গুগল") || c.contains("খোঁজ") || c.contains("search") || c.contains("google")) {
            String q = raw.replaceAll("(?i)গুগলে|গুগল|খোঁজো|খুঁজে দাও|search|google", "").trim();
            if (q.isEmpty()) q = raw;
            Intent web = new Intent(Intent.ACTION_WEB_SEARCH);
            web.putExtra("query", q);
            launch(web, "ওয়েব সার্চ খোলা যায়নি।");
        } else if (c.contains("অ্যাপ") || c.contains("open ")) {
            reply("কোন অ্যাপ খুলতে চান তার নাম বলুন। এই প্রাথমিক সংস্করণে YouTube ও Camera কমান্ড আছে; সব অ্যাপের নাম এখনো যুক্ত করা হয়নি।");
        } else {
            reply("আমি অফলাইনে এই নির্দেশটির নির্ভরযোগ্য উত্তর জানি না। ইন্টারনেট থাকলে ‘গুগলে খোঁজো’ বলে বিষয়টি সার্চ করুন। পূর্ণ অনলাইন AI-এর জন্য পরবর্তী সংস্করণে AI সার্ভিস সংযোগ করতে হবে।");
        }
    }

    private void openSettings() {
        launch(new Intent(android.provider.Settings.ACTION_SETTINGS), "সেটিংস খোলা যায়নি।");
    }

    private void openAppOrSearch(String packageName, String label) {
        Intent app = getPackageManager().getLaunchIntentForPackage(packageName);
        if (app != null) launch(app, label + " খোলা যায়নি।");
        else {
            Intent search = new Intent(Intent.ACTION_WEB_SEARCH);
            search.putExtra("query", label);
            launch(search, label + " ইনস্টল নেই এবং সার্চও খোলা যায়নি।");
        }
    }

    private void launch(Intent i, String error) {
        try { startActivity(i); }
        catch (Exception e) { reply(error); }
    }

    private void reply(String text) {
        output.append("MINI PHONE AI: " + text + "\\n");
        say(text);
    }

    private void say(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mini-phone-ai");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "ভয়েস ব্যবহারের জন্য মাইক্রোফোন অনুমতি দিন।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
