MINI PHONE AI — প্রাথমিক Android APK প্রজেক্ট
============================================

এই সংস্করণে আছে:
- বাংলা ভয়েস ইনপুট (ফোনের Speech Recognition সেবা থাকলে)
- বাংলা TTS উত্তর (ফোনে বাংলা voice data থাকলে)
- সময়, Settings, Wi-Fi/Bluetooth Settings, Camera, YouTube launch/search
- Google/web search intent
- SMS অ্যাপ খোলা এবং নম্বর ডায়ালার খোলা
- কিছু সাধারণ offline command

সীমাবদ্ধতা:
- এটি এখনো পূর্ণ ChatGPT-স্তরের AI নয়।
- প্রকৃত অফলাইন AI উত্তর দিতে বড় local language model এবং ফোনে পর্যাপ্ত RAM/storage লাগবে।
- অনলাইন AI যুক্ত করতে একটি AI API/service লাগবে; সাধারণত API key ও ইন্টারনেট দরকার হয়। এই starter app-এ কোনো API key রাখা নেই।
- “Hey MINI PHONE AI” always-on wake word এখনো নেই।
- Android-এর নিয়মে সাধারণ অ্যাপ থেকে সব সেটিংস, SMS পাঠানো বা incoming call স্বয়ংক্রিয়ভাবে নিয়ন্ত্রণ করা যায় না।
- Voice recognition ফোনে উপলব্ধ সেবা/ভাষা প্যাকের ওপর নির্ভরশীল; সম্পূর্ণ offline speech recognition নিশ্চিত নয়।

APK build:
1. এই ZIP-এর ভেতরের ফাইলগুলো GitHub repository-র root-এ upload করুন।
2. GitHub → Actions → “Build MINI PHONE AI APK” → Run workflow চাপুন।
3. সফল হলে workflow run-এর Artifacts অংশ থেকে MINI-PHONE-AI-APK ডাউনলোড করুন।
4. ZIP extract করে app-debug.apk ইনস্টল করুন। Android চাইলে “Install unknown apps” অনুমতি দিন।

Package: com.miniphone.ai
Minimum Android: 6.0 (API 23); target SDK 28 for prototype compatibility.
