# Jarvis AI — Build notes (বাংলা)

- Android project root: এই ফোল্ডারেই `settings.gradle.kts`, `build.gradle.kts`, `app/` আছে।
- GitHub Actions workflow: `.github/workflows/build-apk.yml`
- Workflow GitHub runner-এ Gradle 9.3.1 ব্যবহার করে Gradle Wrapper তৈরি করার চেষ্টা করবে, তারপর `:app:assembleDebug` চালাবে।
- এই ZIP-এ `gradle/wrapper/gradle-wrapper.properties` আছে, কিন্তু `gradle-wrapper.jar` ইচ্ছাকৃতভাবে ভুয়া ফাইল দিয়ে পূরণ করা হয়নি। Workflow-এ wrapper JAR runner-এ তৈরি হওয়ার কথা।
- এই পরিবেশে Android SDK/Gradle dependencies ডাউনলোড করে সম্পূর্ণ build চালানো যায়নি। তাই APK সফলভাবে তৈরি হয় কি না, তা এখনো যাচাই করা হয়নি।
- GitHub Actions ব্যবহার করতে হলে ZIP extract করে পুরো project GitHub repository-র root-এ upload করতে হবে এবং Actions চালাতে হবে।
