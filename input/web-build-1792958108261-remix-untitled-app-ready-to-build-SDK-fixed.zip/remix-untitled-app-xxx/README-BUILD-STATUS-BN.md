# APK Build Setup (বাংলা)

এই ZIP-এ Android প্রজেক্ট, `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.properties` এবং GitHub Actions workflow রাখা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
`gradle/wrapper/gradle-wrapper.jar` আসল বাইনারি ফাইলটি এই পরিবেশে ইন্টারনেট অ্যাক্সেস না থাকায় যোগ করা যায়নি। তাই এই ZIP-টি এমন কোনো অনলাইন বিল্ডার গ্রহণ করবে বলে নিশ্চয়তা দেওয়া যাচ্ছে না, যেটি চারটি Gradle Wrapper ফাইলই বাধ্যতামূলক করে। ভুয়া/খালি JAR যোগ করা হয়নি।

## GitHub Actions দিয়ে বিল্ড
Workflow Gradle 9.3.1 সেটআপ করে `gradle :app:assembleDebug` চালায়, তাই wrapper JAR ছাড়াও workflow build চালানোর চেষ্টা করতে পারে। GitHub-এ repository-তে push করে Actions চালু করুন। বিল্ড সফল হয়েছে—এমন দাবি করা হচ্ছে না; পরবর্তী compile/dependency error এলে সেটি আলাদাভাবে ঠিক করতে হবে।
