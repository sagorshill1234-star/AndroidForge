package com.example.bhashaai;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 32, 24, 24);
        page.setBackgroundColor(0xFF101A18);

        TextView title = new TextView(this);
        title.setText("Bhasha AI");
        title.setTextSize(30);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("ভিডিও অনুবাদ ও বাংলা ডাবিং");
        subtitle.setTextSize(16);
        subtitle.setTextColor(0xFFB8D2C9);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        Button choose = new Button(this);
        choose.setText("গ্যালারি থেকে ভিডিও নির্বাচন");
        page.addView(choose, new LinearLayout.LayoutParams(-1, -2));
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("video/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, PICK_VIDEO);
        });

        playerView = new PlayerView(this);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        videoParams.topMargin = 16;
        videoParams.bottomMargin = 16;
        page.addView(playerView, videoParams);

        status = new TextView(this);
        status.setText("প্রথমে একটি ভিডিও নির্বাচন করুন।");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(14);
        page.addView(status, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("ডেমো সংস্করণ: ভিডিও নির্বাচন ও প্লে করা যায়। AI অনুবাদ, বাংলা TTS এবং ডাবিং সংযুক্ত করার জন্য নিরাপদ ব্যাকএন্ড/API প্রয়োজন।");
        note.setTextColor(0xFFFFD58A);
        note.setTextSize(13);
        note.setPadding(0, 18, 0, 0);
        page.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(page);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            if (player != null) player.release();
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
            status.setText("ভিডিও চালু হয়েছে। AI অনুবাদ এখনো এই স্টার্টার সংস্করণে যুক্ত নয়।");
        }
    }

    @Override protected void onDestroy() {
        if (player != null) player.release();
        super.onDestroy();
    }
}
