# Bhasha AI — Android Starter

এটি Bhasha AI-এর **স্টার্টার প্রজেক্ট**, সম্পূর্ণ AI অনুবাদক নয়।

## এই সংস্করণে যা কাজ করে
- Android-এর document picker দিয়ে ফোনের ভিডিও নির্বাচন
- Media3/ExoPlayer দিয়ে নির্বাচিত ভিডিও চালানো
- Android 15 / API 35 লক্ষ্য করে build configuration
- GitHub Actions দিয়ে Debug APK তৈরি ও artifact হিসেবে ডাউনলোড

## এখনো যা যুক্ত হয়নি
- স্বয়ংক্রিয় ভাষা শনাক্তকরণ
- Speech-to-Text
- AI বাংলা অনুবাদ
- বাংলা Text-to-Speech
- ভিডিওর অডিও বদলে বাংলা ডাবিং ও subtitle export
- YouTube/Facebook-এর সরাসরি video extraction

## কেন backend দরকার
ভিডিওর অডিও → Speech-to-Text → বাংলা অনুবাদ → বাংলা Text-to-Speech → অডিও/ভিডিওতে সিঙ্ক—এই পুরো pipeline যুক্ত করতে হবে। API key কখনো Android APK-তে hardcode করবেন না; একটি নিরাপদ backend-এ রাখুন। ভিডিও/অডিও আপলোডের আগে ব্যবহারকারীর সম্মতি ও কনটেন্ট ব্যবহারের অধিকার নিশ্চিত করতে হবে।

## GitHub Actions দিয়ে APK
1. ZIP extract করে সব ফাইল GitHub repository-র root-এ upload করুন।
2. `.github/workflows/build.yml` ফাইলটি repository-তে আছে কি না দেখুন।
3. GitHub → Actions → Build Bhasha AI APK → Run workflow চাপুন।
4. সফল হলে workflow run-এর নিচে `BhashaAI-debug-apk` artifact download করুন।
5. ZIP extract করে `app-debug.apk` ফোনে install করুন।

## Sketchware Pro সম্পর্কে
এই প্রজেক্টটি native Android Gradle project; Sketchware Pro project নয়। উন্নত Media3 playback এবং পরবর্তী AI pipeline-এর জন্য native Android project বেশি উপযোগী। ফোন থেকেই GitHub Actions দিয়ে build করা যাবে।
