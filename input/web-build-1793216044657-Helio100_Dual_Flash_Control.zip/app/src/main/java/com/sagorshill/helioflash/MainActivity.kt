package com.sagorshill.helioflash

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cameraManager: CameraManager
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val flashIds = mutableListOf<String>()
    private val onStates = mutableMapOf<String, Boolean>()
    private val buttons = mutableMapOf<String, Button>()
    private val permissionRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), permissionRequest)
        } else {
            discoverFlashUnits()
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 28)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Helio Dual Flash"
            textSize = 26f
            gravity = Gravity.CENTER
        }, match())
        root.addView(TextView(this).apply {
            text = "Helio 100 • Android 15\nপেছনের ফ্ল্যাশ পরীক্ষা ও নিয়ন্ত্রণ"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }, match())

        status = TextView(this).apply {
            text = "ফ্ল্যাশ খোঁজা হচ্ছে…"
            textSize = 16f
            setPadding(0, 8, 0, 18)
        }
        root.addView(status, match())

        addButton("সব ফ্ল্যাশ বন্ধ করুন") { turnAllOff() }
        addButton("সব উপলভ্য ফ্ল্যাশ একসঙ্গে চালু") { turnAllOn() }
        root.addView(TextView(this).apply {
            text = "\nআলাদা ফ্ল্যাশ"
            textSize = 20f
            setPadding(0, 20, 0, 8)
        }, match())
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addButton(label: String, action: () -> Unit): Button {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            setOnClickListener { action() }
        }
        root.addView(button, match())
        return button
    }

    private fun discoverFlashUnits() {
        flashIds.clear()
        try {
            for (id in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    flashIds.add(id)
                    onStates[id] = false
                }
            }
        } catch (e: Exception) {
            status.text = "ক্যামেরা তথ্য পড়া যায়নি: ${e.message ?: "অজানা সমস্যা"}"
            return
        }

        if (flashIds.isEmpty()) {
            status.text = "পেছনের আলাদা নিয়ন্ত্রণযোগ্য ফ্ল্যাশ পাওয়া যায়নি। ফোনের ফ্ল্যাশ হার্ডওয়্যার/সিস্টেম সীমাবদ্ধ হতে পারে।"
            return
        }

        status.text = "পেছনের ফ্ল্যাশ-সমর্থিত ক্যামেরা পাওয়া গেছে: ${flashIds.size}টি।\nনোট: দুটি LED এক ক্যামেরার সঙ্গে যুক্ত থাকলে Android সেগুলো আলাদা করতে নাও পারে।"
        flashIds.forEachIndexed { index, id ->
            val button = addButton("ফ্ল্যাশ ${index + 1} চালু") { toggle(id, index) }
            buttons[id] = button
        }
    }

    private fun toggle(id: String, index: Int) {
        val newState = !(onStates[id] ?: false)
        try {
            cameraManager.setTorchMode(id, newState)
            onStates[id] = newState
            buttons[id]?.text = "ফ্ল্যাশ ${index + 1} " + if (newState) "বন্ধ করুন" else "চালু করুন"
        } catch (e: Exception) {
            Toast.makeText(this, "এই ফ্ল্যাশ আলাদাভাবে নিয়ন্ত্রণ করা যাচ্ছে না: ${e.message ?: "সিস্টেম সীমাবদ্ধতা"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun turnAllOn() {
        flashIds.forEach { id ->
            try {
                cameraManager.setTorchMode(id, true)
                onStates[id] = true
            } catch (_: Exception) {}
        }
        refreshButtons()
        Toast.makeText(this, "সমর্থিত ফ্ল্যাশ চালু করার চেষ্টা করা হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun turnAllOff() {
        flashIds.forEach { id ->
            try {
                cameraManager.setTorchMode(id, false)
                onStates[id] = false
            } catch (_: Exception) {}
        }
        refreshButtons()
    }

    private fun refreshButtons() {
        flashIds.forEachIndexed { index, id ->
            buttons[id]?.text = "ফ্ল্যাশ ${index + 1} " + if (onStates[id] == true) "বন্ধ করুন" else "চালু করুন"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                discoverFlashUnits()
            } else {
                status.text = "ফ্ল্যাশ নিয়ন্ত্রণের জন্য Camera permission দিতে হবে।"
            }
        }
    }

    override fun onDestroy() {
        turnAllOff()
        super.onDestroy()
    }
}
