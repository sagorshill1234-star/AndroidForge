package com.sagorshill.flashbrightness

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cameraManager: CameraManager
    private lateinit var status: TextView
    private lateinit var brightnessLabel: TextView
    private lateinit var brightnessSeek: SeekBar
    private lateinit var toggleButton: Button
    private var backCameraId: String? = null
    private var torchOn = false
    private var maxStrength = 1
    private var currentStrength = 1
    private val permissionRequest = 812

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), permissionRequest)
        } else {
            findFlash()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }
        setContentView(root)

        root.addView(TextView(this).apply {
            text = "🔦 Flash Brightness"
            textSize = 25f
            gravity = Gravity.CENTER
        }, params())

        root.addView(TextView(this).apply {
            text = "Helio 100 • Android 15\nফ্ল্যাশের আলো চালু/বন্ধ ও উজ্জ্বলতা নিয়ন্ত্রণ"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 26)
        }, params())

        status = TextView(this).apply {
            text = "ফ্ল্যাশ পরীক্ষা করা হচ্ছে…"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 18)
        }
        root.addView(status, params())

        toggleButton = Button(this).apply {
            text = "ফ্ল্যাশ চালু করুন"
            textSize = 18f
            setOnClickListener { setTorch(!torchOn) }
        }
        root.addView(toggleButton, params())

        brightnessLabel = TextView(this).apply {
            text = "উজ্জ্বলতা: সমর্থন পরীক্ষা হচ্ছে"
            textSize = 18f
            setPadding(0, 24, 0, 6)
        }
        root.addView(brightnessLabel, params())

        brightnessSeek = SeekBar(this).apply {
            max = 100
            progress = 100
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) changeStrength(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(brightnessSeek, params())

        root.addView(TextView(this).apply {
            text = "দ্রষ্টব্য: আলোর উজ্জ্বলতা কমানো/বাড়ানো ফোনের হার্ডওয়্যার ও Android সমর্থন করলে কাজ করবে।"
            textSize = 14f
            setPadding(0, 22, 0, 0)
        }, params())
    }

    private fun params() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun findFlash() {
        try {
            backCameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val c = cameraManager.getCameraCharacteristics(id)
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK &&
                    c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            val id = backCameraId
            if (id == null) {
                status.text = "পেছনের ফ্ল্যাশ পাওয়া যায়নি।"
                brightnessLabel.text = "উজ্জ্বলতা নিয়ন্ত্রণ অনুপলব্ধ"
                return
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val c = cameraManager.getCameraCharacteristics(id)
                val strength = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                maxStrength = strength.coerceAtLeast(1)
            } else {
                maxStrength = 1
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxStrength > 1) {
                brightnessSeek.isEnabled = true
                brightnessSeek.max = maxStrength
                currentStrength = maxStrength
                brightnessSeek.progress = maxStrength
                brightnessLabel.text = "উজ্জ্বলতা: ${maxStrength}/${maxStrength}"
                status.text = "ফ্ল্যাশ পাওয়া গেছে। উজ্জ্বলতা নিয়ন্ত্রণ সমর্থিত হতে পারে।"
            } else {
                brightnessSeek.isEnabled = false
                brightnessSeek.progress = 100
                brightnessLabel.text = "উজ্জ্বলতা পরিবর্তন সমর্থিত নয়"
                status.text = "ফ্ল্যাশ পাওয়া গেছে। এই ফোনে Android-এর মাধ্যমে উজ্জ্বলতা বদলানোর সুবিধা শনাক্ত হয়নি।"
            }
        } catch (e: Exception) {
            status.text = "ফ্ল্যাশ পরীক্ষা করা যায়নি: ${e.message ?: "সিস্টেম সমস্যা"}"
        }
    }

    private fun setTorch(on: Boolean) {
        val id = backCameraId ?: return
        try {
            if (on && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxStrength > 1) {
                cameraManager.turnOnTorchWithStrengthLevel(id, currentStrength.coerceIn(1, maxStrength))
            } else {
                cameraManager.setTorchMode(id, on)
            }
            torchOn = on
            toggleButton.text = if (on) "ফ্ল্যাশ বন্ধ করুন" else "ফ্ল্যাশ চালু করুন"
            if (on) status.text = "ফ্ল্যাশ চালু"
            else status.text = "ফ্ল্যাশ বন্ধ"
        } catch (e: Exception) {
            Toast.makeText(this, "এই ফোনে ফ্ল্যাশ নিয়ন্ত্রণ করা যায়নি: ${e.message ?: "সিস্টেম সীমাবদ্ধতা"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun changeStrength(progress: Int) {
        if (maxStrength <= 1) return
        currentStrength = progress.coerceIn(1, maxStrength)
        brightnessLabel.text = "উজ্জ্বলতা: $currentStrength/$maxStrength"
        if (torchOn) {
            try {
                backCameraId?.let { cameraManager.turnOnTorchWithStrengthLevel(it, currentStrength) }
            } catch (e: Exception) {
                Toast.makeText(this, "উজ্জ্বলতা বদলানো যাচ্ছে না", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) findFlash()
            else status.text = "ফ্ল্যাশ চালাতে Camera permission দিতে হবে।"
        }
    }

    override fun onDestroy() {
        if (::cameraManager.isInitialized && backCameraId != null && torchOn) {
            try { cameraManager.setTorchMode(backCameraId!!, false) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
