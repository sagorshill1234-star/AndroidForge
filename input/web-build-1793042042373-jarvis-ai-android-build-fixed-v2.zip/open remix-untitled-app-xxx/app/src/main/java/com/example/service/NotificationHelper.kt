package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

object NotificationHelper {

    private const val CHANNEL_CARE_ID = "jarvis_phone_care_channel"
    private const val CHANNEL_MEDICINE_ID = "jarvis_medicine_channel"

    fun initNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val careChannel = NotificationChannel(
                CHANNEL_CARE_ID,
                "ফোন কেয়ার ও ব্যাটারি নোটিফিকেশন",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "ব্যাটারি চার্জ লিমিট ও র‍্যাম বুস্টার অ্যালার্ট"
            }

            val medChannel = NotificationChannel(
                CHANNEL_MEDICINE_ID,
                "ঔষধ সেবনের রিমাইন্ডার",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "সময়মতো ঔষধ সেবন অ্যালার্ট ও স্বাস্থ্য পরামর্শ"
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(careChannel)
            manager.createNotificationChannel(medChannel)
        }
    }

    fun showBatteryAlertNotification(context: Context, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_CARE_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(101, notification)
        } catch (_: SecurityException) {}
    }

    fun showMedicineReminderNotification(context: Context, medName: String, dosage: String, mealInfo: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val message = "ঔষধ সেবনের সময় হয়েছে: $medName ($dosage) - $mealInfo"
        val notification = NotificationCompat.Builder(context, CHANNEL_MEDICINE_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏰ ঔষধ সেবনের রিমাইন্ডার - অহন")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), notification)
        } catch (_: SecurityException) {}
    }
}
