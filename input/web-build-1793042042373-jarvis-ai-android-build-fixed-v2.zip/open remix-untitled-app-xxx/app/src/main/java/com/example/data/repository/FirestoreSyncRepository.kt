package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.MedicineReminderEntity
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreSyncRepository(private val context: Context) {

    private val db: FirebaseFirestore by lazy {
        val databaseId = context.getString(R.string.firestore_database_id)
        FirebaseFirestore.getInstance(com.google.firebase.FirebaseApp.getInstance(), databaseId)
    }

    private val auth get() = Firebase.auth

    fun getCurrentUser() = auth.currentUser

    private fun requireUserId(): String {
        return auth.currentUser?.uid ?: error("User must be signed in with Google")
    }

    suspend fun syncUserProfile(nickname: String, persona: String, isDarkMode: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        try {
            val userDoc = db.collection("users").document(uid)
            val profileData = mapOf(
                "userId" to uid,
                "nickname" to nickname,
                "persona" to persona,
                "isDarkMode" to isDarkMode,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userDoc.set(profileData, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Failed to sync user profile: ${e.message}", e)
        }
    }

    suspend fun syncChatMessage(message: ChatMessageEntity) {
        val uid = auth.currentUser?.uid ?: return
        try {
            val messagesCol = db.collection("users").document(uid).collection("chat_messages")
            val msgData = mapOf(
                "userId" to uid,
                "sender" to message.sender,
                "content" to message.content,
                "timestamp" to FieldValue.serverTimestamp(),
                "isOfflineMode" to message.isOfflineMode
            )
            messagesCol.add(msgData).await()
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Failed to sync chat message: ${e.message}", e)
        }
    }

    suspend fun syncMedicineReminder(reminder: MedicineReminderEntity) {
        val uid = auth.currentUser?.uid ?: return
        try {
            val remCol = db.collection("users").document(uid).collection("medicine_reminders")
            val remData = mapOf(
                "userId" to uid,
                "medicineName" to reminder.medicineName,
                "dosage" to reminder.dosage,
                "timeHour" to reminder.timeHour,
                "timeMinute" to reminder.timeMinute,
                "mealTiming" to reminder.mealTiming,
                "category" to reminder.category,
                "notes" to reminder.notes,
                "isActive" to reminder.isActive,
                "isTakenToday" to reminder.isTakenToday,
                "createdAt" to FieldValue.serverTimestamp()
            )
            remCol.document(reminder.id.toString()).set(remData, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Failed to sync medicine reminder: ${e.message}", e)
        }
    }

    suspend fun deleteMedicineReminder(reminderId: Long) {
        val uid = auth.currentUser?.uid ?: return
        try {
            db.collection("users").document(uid)
                .collection("medicine_reminders")
                .document(reminderId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e("FirestoreSync", "Failed to delete medicine reminder from cloud: ${e.message}", e)
        }
    }
}
