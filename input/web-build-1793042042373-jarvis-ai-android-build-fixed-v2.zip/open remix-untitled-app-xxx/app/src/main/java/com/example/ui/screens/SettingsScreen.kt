package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AppPersona
import com.example.MainViewModel
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkNavy
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentNickname by viewModel.nickname.collectAsState()
    val isOfflineMode by viewModel.isOfflineMode.collectAsState()
    val isVoiceTtsEnabled by viewModel.isVoiceTtsEnabled.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val selectedPersona by viewModel.selectedPersona.collectAsState()

    var nameInput by remember(currentNickname) { mutableStateOf(currentNickname) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDarkNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        Text(
            text = "⚙️ সেটিংস ও কাস্টমাইজেশন",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = CyberCyan
        )
        Text(
            text = "AI অ্যাসিস্ট্যান্টের নাম, পার্সোনা, ভয়েস ও ইন্টারফেস পরিবর্তন করুন",
            fontSize = 12.sp,
            color = CyberTextSecondary
        )

        // Google Account & Cloud Sync Card
        val authManager = viewModel.authManager
        val currentUser by authManager.currentUser.collectAsState()
        val authLoading by authManager.isLoading.collectAsState()
        val authError by authManager.errorMessage.collectAsState()
        val context = androidx.compose.ui.platform.LocalContext.current
        val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()

        Card(
            modifier = Modifier.fillMaxWidth().testTag("google_account_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (currentUser != null) CyberEmerald.copy(alpha = 0.5f) else CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (currentUser != null) Icons.Default.CloudDone else Icons.Default.AccountCircle,
                        contentDescription = "Cloud Sync",
                        tint = if (currentUser != null) CyberEmerald else CyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (currentUser != null) "Google ক্লাউড সিঙ্ক সক্রিয়" else "Google ক্লাউড ব্যাকআপ ও সিঙ্ক",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CyberTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (currentUser != null) {
                    Text(
                        text = "লগইন করা আছে: ${currentUser?.displayName ?: "Google User"} (${currentUser?.email ?: ""})",
                        fontSize = 12.sp,
                        color = CyberTextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { authManager.signOut(coroutineScope) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCardBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("google_sign_out_button")
                    ) {
                        Text("সাইন আউট করুন", color = CyberTextPrimary, fontSize = 12.sp)
                    }
                } else {
                    Text(
                        text = "আপনার চ্যাট ইতিহাস, ওষুধের রিমাইন্ডার এবং পার্সোনা সেটিংস ক্লাউডে সুরক্ষিত রাখতে Google দিয়ে সাইন-ইন করুন।",
                        fontSize = 12.sp,
                        color = CyberTextSecondary,
                        lineHeight = 17.sp
                    )
                    if (authError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = authError ?: "",
                            color = com.example.ui.theme.CyberPink,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val activity = context as? android.app.Activity
                            if (activity != null) {
                                authManager.signInWithGoogle(activity, coroutineScope)
                            }
                        },
                        enabled = !authLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("google_sign_in_button")
                    ) {
                        if (authLoading) {
                            androidx.compose.material3.CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CyberDarkNavy,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                "Sign in with Google",
                                color = CyberDarkNavy,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Install on Android Phone & GitHub Mode Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("install_on_phone_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "Install on Phone",
                        tint = CyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "📲 আসল অ্যান্ড্রয়েড ফোনে ইনস্টল করবেন যেভাবে",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CyberCyan
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "আপনি এমুলেটর ছাড়াও নিজের ফোনে সরাসরি APK ইনস্টল করে অ্যাপটি ব্যবহার করতে পারেন:",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberDarkNavy)
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "১. AI Studio সেটিংস থেকে সরাসরি APK:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = CyberAmber
                        )
                        Text(
                            text = "AI Studio-র উপরের ডানপাশে 'Settings / Export' মেন্যু থেকে 'Generate APK / AAB' বা 'Export project as ZIP' ডাউনলোড করে ফোনে নিয়ে ইনস্টল করুন।",
                            fontSize = 11.sp,
                            color = CyberTextPrimary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "২. GitHub Releases মোড (স্বয়ংক্রিয়):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = CyberEmerald
                        )
                        Text(
                            text = "প্রোজেক্টটি GitHub-এ 'Push' করলেই আমাদের তৈরি করা .github/workflows/build-apk.yml স্বয়ংক্রিয়ভাবে ২ মিনিটে Debug APK তৈরি করে GitHub Releases-এ তুলে দেবে। ফোনে গিটহাব থেকে সরাসরি .apk ডাউনলোড করুন।",
                            fontSize = 11.sp,
                            color = CyberTextPrimary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "💡 টিপস: প্রথমবারের মতো ইনস্টল করার সময় ফোনে 'Install from unknown sources' অনুমোদন দিলে অনায়াসেই ইনস্টল হয়ে যাবে।",
                            fontSize = 11.sp,
                            color = CyberTextSecondary
                        )
                    }
                }
            }
        }

        // Nickname Setting Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("nickname_setting_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Nickname",
                        tint = CyberAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI অ্যাসিস্ট্যান্টের ডাকনাম (Nickname)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CyberTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "আপনি এই নামে ডাকলে ও সাড়া দেবে এবং বন্ধু বা গার্লফ্রেন্ডের মতো গল্প করবে।",
                    fontSize = 12.sp,
                    color = CyberTextSecondary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        placeholder = { Text("যেমন: অহন, Ahon, Jarvis") },
                        modifier = Modifier.weight(1f).testTag("nickname_input_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.setNickname(nameInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("save_nickname_button")
                    ) {
                        Text("সেভ", color = CyberDarkNavy, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Persona Selection Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("persona_setting_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = "Persona",
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "অ্যাসিস্ট্যান্ট পার্সোনা ও কথা বলার ধরণ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CyberTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                AppPersona.entries.forEach { persona ->
                    val isSelected = selectedPersona == persona
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) CyberCyan.copy(alpha = 0.15f) else CyberDarkNavy)
                            .border(
                                1.dp,
                                if (isSelected) CyberCyan else CyberCardBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setPersona(persona) }
                            .padding(12.dp)
                            .testTag("persona_${persona.name}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = persona.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) CyberCyan else CyberTextPrimary
                            )
                            Text(
                                text = persona.description,
                                fontSize = 11.sp,
                                color = CyberTextSecondary
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Voice & Toggles Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("toggles_setting_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Voice TTS Toggle
                SettingToggleRow(
                    icon = Icons.Default.RecordVoiceOver,
                    title = "ভয়েস ফিডব্যাক (TTS)",
                    subtitle = "অহন কথা বলে উত্তর দেবে",
                    checked = isVoiceTtsEnabled,
                    onCheckedChange = { viewModel.setVoiceTtsEnabled(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Offline Mode Toggle
                SettingToggleRow(
                    icon = Icons.Default.WifiOff,
                    title = "অফলাইন ইন্টেলিজেন্স মোড",
                    subtitle = "ইন্টারনেট ছাড়াও ফোন কেয়ার, র‍্যাম বুস্ট ও স্বাস্থ্য পরামর্শ প্রদান",
                    checked = isOfflineMode,
                    onCheckedChange = { viewModel.setOfflineMode(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Dark Mode Toggle
                SettingToggleRow(
                    icon = Icons.Default.DarkMode,
                    title = "সাইবার ডার্ক মোড",
                    subtitle = "কাস্টমাইজড নিয়ন ইন্টারফেস ও চোখের সুরক্ষা",
                    checked = isDarkMode,
                    onCheckedChange = { viewModel.setDarkMode(it) }
                )
            }
        }

        // Security & Local Encryption Badge
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberCard.copy(alpha = 0.7f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberEmerald.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(CyberEmerald.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Encrypted",
                        tint = CyberEmerald,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "🔒 শক্তিশালী এনক্রিপশন ও প্রাইভেসি",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = CyberEmerald
                    )
                    Text(
                        text = "আপনার চ্যাট হিস্ট্রি, ঔষধের তালিকা ও ফোন হেলথ ডেটা সম্পূর্ণ এনক্রিপ্টেড এবং আপনার ডিভাইসের লোকাল স্টোরেজে সুরক্ষিত থাকে।",
                        fontSize = 11.sp,
                        color = CyberTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun SettingToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = CyberCyan,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = CyberTextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = CyberTextSecondary
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberDarkNavy,
                checkedTrackColor = CyberCyan,
                uncheckedThumbColor = CyberTextSecondary,
                uncheckedTrackColor = CyberCardBorder
            )
        )
    }
}
