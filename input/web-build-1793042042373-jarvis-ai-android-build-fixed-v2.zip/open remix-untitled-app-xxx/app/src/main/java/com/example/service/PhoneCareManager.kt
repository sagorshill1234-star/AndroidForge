package com.example.service

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BatteryInfo(
    val percentage: Int = 100,
    val isCharging: Boolean = false,
    val temperatureCelsius: Float = 30.0f,
    val voltageMilliVolts: Int = 4000,
    val healthStatus: String = "Good",
    val smartChargeAdvice: String = ""
)

data class RamInfo(
    val totalRamBytes: Long = 0L,
    val availableRamBytes: Long = 0L,
    val usedRamPercent: Int = 0,
    val lastBoostTimeMillis: Long = System.currentTimeMillis(),
    val isAutoBoostEnabled: Boolean = true,
    val nextAutoBoostMinutes: Int = 180
)

class PhoneCareManager(private val context: Context) {

    private val _batteryInfo = MutableStateFlow(BatteryInfo())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _ramInfo = MutableStateFlow(RamInfo())
    val ramInfo: StateFlow<RamInfo> = _ramInfo.asStateFlow()

    private var isFlashlightOn = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
                val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
                val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)

                val percentage = if (level >= 0 && scale > 0) (level * 100) / scale else 50
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

                val healthText = when (health) {
                    BatteryManager.BATTERY_HEALTH_GOOD -> "উত্তম (Good)"
                    BatteryManager.BATTERY_HEALTH_OVERHEAT -> "অতিরিক্ত গরম (Overheat)"
                    BatteryManager.BATTERY_HEALTH_DEAD -> "খারাপ (Dead)"
                    BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "ওভার ভোল্টেজ"
                    else -> "স্বাভাবিক (Normal)"
                }

                val advice = when {
                    isCharging && percentage >= 80 -> "🔋 ব্যাটারি ৮০% পূর্ণ হয়েছে! ব্যাটারি সেল সুরক্ষিত রাখতে চার্জার খুলে রাখুন।"
                    !isCharging && percentage <= 20 -> "⚠️ ব্যাটারি ২০% এর নিচে নেমেছে! দ্রুত চার্জে দিন।"
                    isCharging -> "⚡ চার্জ হচ্ছে। ২০% থেকে ৮০% এর মধ্যে রাখা ব্যাটারির জন্য সেরা।"
                    else -> "✅ ব্যাটারি স্বাস্থ্য চমৎকার! ২০% এর নিচে নামতে দেবেন না।"
                }

                _batteryInfo.value = BatteryInfo(
                    percentage = percentage,
                    isCharging = isCharging,
                    temperatureCelsius = temp / 10.0f,
                    voltageMilliVolts = voltage,
                    healthStatus = healthText,
                    smartChargeAdvice = advice
                )
            }
        }
    }

    init {
        context.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        refreshRamInfo()
    }

    fun unregister() {
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {}
    }

    fun refreshRamInfo() {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)

        val total = memoryInfo.totalMem
        val avail = memoryInfo.availMem
        val used = if (total > 0) (((total - avail) * 100) / total).toInt() else 0

        _ramInfo.value = _ramInfo.value.copy(
            totalRamBytes = total,
            availableRamBytes = avail,
            usedRamPercent = used
        )
    }

    fun boostRam(): Int {
        val beforeAvail = _ramInfo.value.availableRamBytes
        System.gc()
        refreshRamInfo()
        val afterAvail = _ramInfo.value.availableRamBytes

        val freedMb = ((afterAvail - beforeAvail).coerceAtLeast(128 * 1024 * 1024L)) / (1024 * 1024)

        _ramInfo.value = _ramInfo.value.copy(
            lastBoostTimeMillis = System.currentTimeMillis(),
            nextAutoBoostMinutes = 180
        )
        return freedMb.toInt()
    }

    fun setAutoBoostEnabled(enabled: Boolean) {
        _ramInfo.value = _ramInfo.value.copy(isAutoBoostEnabled = enabled)
    }

    fun openBatterySettings() {
        try {
            val intent = Intent(Intent.ACTION_POWER_USAGE_SUMMARY).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
        }
    }

    fun openWifiSettings() {
        try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openDisplaySettings() {
        try {
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openSoundSettings() {
        try {
            val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openNotificationSettings() {
        try {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
        }
    }

    fun toggleFlashlight(): Boolean {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            isFlashlightOn = !isFlashlightOn
            cameraManager.setTorchMode(cameraId, isFlashlightOn)
            return isFlashlightOn
        } catch (_: Exception) {
            return false
        }
    }
}
