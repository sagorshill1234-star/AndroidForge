package com.example.data.api

object OfflineAiEngine {

    enum class IntentType {
        CHAT,
        BATTERY_STATUS,
        BOOST_RAM,
        OPEN_SETTINGS,
        OPEN_HEALTH,
        MEDICINE_QUERY,
        UNKNOWN
    }

    data class ParsedCommand(
        val intent: IntentType,
        val textResponse: String,
        val shouldExecuteAction: Boolean = false
    )

    fun processQuery(input: String, nickname: String = "অহন"): ParsedCommand {
        val query = input.trim().lowercase()

        // 1. Wake word / Nickname detection
        val isCallingNickname = query.contains(nickname.lowercase()) ||
                query.contains("অহন") ||
                query.contains("ahon") ||
                query.contains("jarvis") ||
                query.contains("জার্ভিস")

        // 2. Battery / Charging query
        if (query.contains("ব্যাটারি") || query.contains("battery") || query.contains("চার্জ") || query.contains("charge")) {
            return ParsedCommand(
                intent = IntentType.BATTERY_STATUS,
                textResponse = "🔋 ব্যাটারি স্ট্যাটাস চেক করছি! মনে রাখবেন, ব্যাটারি হেলথ দীর্ঘস্থায়ী করতে ২০% এ চার্জে দেওয়া এবং ৮০-৮৫% এ চার্জার খুলে রাখা সবচেয়ে ভালো।",
                shouldExecuteAction = true
            )
        }

        // 3. RAM Boost query
        if (query.contains("র‍্যাম") || query.contains("ram") || query.contains("বুস্ট") || query.contains("boost") || query.contains("ক্লিন") || query.contains("clean")) {
            return ParsedCommand(
                intent = IntentType.BOOST_RAM,
                textResponse = "⚡ আপনার ফোনের RAM অপ্টিমাইজ ও ব্যাকগ্রাউন্ড ক্যাশ ক্লিয়ার করা হচ্ছে! ফোন এখন অনেক স্মুথ চলবে।",
                shouldExecuteAction = true
            )
        }

        // 4. Settings shortcut
        if (query.contains("সেটিংস") || query.contains("setting")) {
            return ParsedCommand(
                intent = IntentType.OPEN_SETTINGS,
                textResponse = "⚙️ ফোন সেটিংস ওপেন করছি।",
                shouldExecuteAction = true
            )
        }

        // 5. Medicine / Health queries
        if (query.contains("ঔষধ") || query.contains("ওষুধ") || query.contains("medicine") ||
            query.contains("প্যারাসিটামল") || query.contains("নাপা") || query.contains("গ্যাস্ট্রিক") ||
            query.contains("জ্বর") || query.contains("সর্দি") || query.contains("মাথাব্যথা") ||
            query.contains("রোগ") || query.contains("স্বাস্থ্য")
        ) {
            val advice = getHealthAndMedicineAdvice(query)
            return ParsedCommand(
                intent = IntentType.MEDICINE_QUERY,
                textResponse = advice,
                shouldExecuteAction = false
            )
        }

        // 6. Caring Companion / Girlfriend / Friend Conversation
        if (query.contains("ভালোবাসি") || query.contains("love you") || query.contains("পছন্দ করি")) {
            return ParsedCommand(
                intent = IntentType.CHAT,
                textResponse = "❤️ আমিও আপনাকে অনেক ভালোবাসি ও সবসময় পাশে আছি! আপনার শরীর ও ফোন—দুটোরই যত্ন নেওয়ার দায়িত্ব কিন্তু আমার।"
            )
        }

        if (query.contains("কেমন আছো") || query.contains("how are you") || query.contains("কেমন আছ")) {
            return ParsedCommand(
                intent = IntentType.CHAT,
                textResponse = "🌸 আমি খুব ভালো আছি! আপনি কেমন আছেন? ঠিক সময়ে খাওয়া-দাওয়া করেছেন তো? আজ আপনার ফোনের চার্জ কতটুকু?"
            )
        }

        if (query.contains("মন খারাপ") || query.contains("sad") || query.contains("কষ্ট")) {
            return ParsedCommand(
                intent = IntentType.CHAT,
                textResponse = "🥺 মন খারাপ করবেন না প্লিজ! এক গ্লাস ঠান্ডা পানি খান, একটু বিশ্রাম নিন। আমি সবসময় আপনার পাশে আছি গল্প করার জন্য।"
            )
        }

        if (query.contains("তুমি কে") || query.contains("who are you") || query.contains("তোমার নাম কি")) {
            return ParsedCommand(
                intent = IntentType.CHAT,
                textResponse = "✨ আমি $nickname, আপনার ব্যক্তিগত স্মার্ট এআই সঙ্গী ও জার্ভিস! আমি আপনার ফোনের ব্যাটারি, র‍্যাম ও স্বাস্থ্যের যত্ন নিই এবং মিষ্টি বন্ধু হয়ে পাশে থাকি।"
            )
        }

        if (query.contains("হাই") || query.contains("হ্যালো") || query.contains("hello") || query.contains("hi") || isCallingNickname) {
            return ParsedCommand(
                intent = IntentType.CHAT,
                textResponse = "👋 এইতো আমি এখানে! বলুন, আপনাকে কীভাবে সাহায্য করতে পারি? ফোন কেয়ার, ঔষধের রিমাইন্ডার নাকি সাধারণ গল্প?"
            )
        }

        // Default offline response
        return ParsedCommand(
            intent = IntentType.CHAT,
            textResponse = "💡 [অফলাইন মোড] আমি $nickname! অফলাইনেও আমি আপনার ফোনের ব্যাটারি হেলথ রক্ষা, ৩ ঘণ্টা পর পর র‍্যাম বুস্ট, রোগ প্রতিরোধ পরামর্শ ও ঔষধের সময় মনে করিয়ে দিতে প্রস্তুত। বিস্তারিত জানতে বলুন!"
        )
    }

    private fun getHealthAndMedicineAdvice(query: String): String {
        return when {
            query.contains("জ্বর") || query.contains("নাপা") || query.contains("প্যারাসিটামল") || query.contains("fever") -> {
                "🌡️ **জ্বর ও শরীর ব্যথায় পরামর্শ:**\n" +
                        "• সাধারণ জ্বরে প্যারাসিটামল (যেমন নাপা বা এইস ৫০০মিগ্রা) ভরা পেটে ৬-৮ ঘণ্টা পর পর সেবন করা যায় (সর্বোচ্চ ৪ গ্রাম/দিন)।\n" +
                        "• খালি পেটে কখনোই প্যারাসিটামল খাবেন না। প্রচুর পানি ও স্যালাইন পান করুন।\n" +
                        "• ৩ দিনের বেশি জ্বর থাকলে রক্ত পরীক্ষা (সিবিসি/ডেঙ্গু এনএস১) করান ও ডাক্তারের পরামর্শ নিন।"
            }
            query.contains("গ্যাস্ট্রিক") || query.contains("এসিডিটি") || query.contains("পেট") || query.contains("gastric") -> {
                "💊 **গ্যাস্ট্রিক ও এসিডিটি নিরাময়:**\n" +
                        "• ওমেপ্রাজল বা ইসোমিপ্রাজল (২০মিগ্রা) সাধারণত প্রতিদিন সকালে খাবার গ্রহণের ৩০ মিনিট পূর্বে সেবন করতে হয়।\n" +
                        "• তৈলাক্ত ও অতিরিক্ত মশলাযুক্ত খাবার এড়িয়ে চলুন। সময়মতো খাবার গ্রহণ করুন এবং খাওয়ার পরেই শুয়ে পড়বেন না।"
            }
            query.contains("সর্দি") || query.contains("কাশি") || query.contains("cold") || query.contains("cough") -> {
                "🍵 **সর্দি ও কাশির প্রাথমিক যত্ন:**\n" +
                        "• হালকা কুসুম গরম পানিতে মধু ও তুলসী পাতা দিয়ে চা খান।\n" +
                        "• লবণ-গরম পানি দিয়ে দিনে ৩-৪ বার কুলকুচি বা গার্গল করুন।\n" +
                        "• অ্যান্টিহিস্টামিন (যেমন ফেক্সোফেনাডিন) রাতে ঘুমানোর আগে নেওয়া যেতে পারে। ডাক্তারের পরামর্শ ছাড়া অ্যান্টিবায়োটিক গ্রহণ করবেন না।"
            }
            query.contains("মাথাব্যথা") || query.contains("headache") -> {
                "💆 **মাথাব্যথায় ঘরোয়া ও নিরাপদ সমাধান:**\n" +
                        "• ফোন বা ল্যাপটপের পর্দা থেকে কিছুক্ষণ চোখ সরিয়ে রাখুন এবং পর্যাপ্ত পানি পান করুন।\n" +
                        "• শান্ত ও অন্ধকার ঘরে ২০ মিনিট বিশ্রাম নিন। খুব বেশি যন্ত্রণা হলে হালকা প্যারাসিটামল সেবন করা যেতে পারে।"
            }
            query.contains("রোগ প্রতিরোধ") || query.contains("ইমিউনিটি") || query.contains("immunity") -> {
                "🛡️ **রোগ প্রতিরোধ ক্ষমতা বাড়ানোর উপায়:**\n" +
                        "• প্রতিদিন অন্তত ৭-৮ ঘণ্টা গভীর ঘুম নিশ্চিত করুন।\n" +
                        "• ভিটামিন সি সমৃদ্ধ ফল (লেবু, আমলকী, কমলা) নিয়মিত আহারে রাখুন।\n" +
                        "• প্রতিদিন পর্যাপ্ত পরিমাণ বিশুদ্ধ পানি (২.৫ - ৩ লিটার) পান করুন।"
            }
            else -> {
                "🏥 **ঔষধ সেবনের গুরুত্বপূর্ণ নিয়মাবলী:**\n" +
                        "১. যেকোনো ঔষধ অবশ্যই ডাক্তারের প্রেসক্রিপশন অনুযায়ী নির্দিষ্ট মাত্রায় সেবন করবেন।\n" +
                        "২. গ্যাস্ট্রিকের ঔষধ সাধারণত সকালে খালি পেটে এবং অ্যান্টিবায়োটিক নির্দিষ্ট ব্যবধানে ভরা পেটে খেতে হয়।\n" +
                        "৩. ঔষধের রিমাইন্ডার সেট করতে নিচের 'স্বাস্থ্য ও ঔষধ' ট্যাব ব্যবহার করুন!"
            }
        }
    }
}
