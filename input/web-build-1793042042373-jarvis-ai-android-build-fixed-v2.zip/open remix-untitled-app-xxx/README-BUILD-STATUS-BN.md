# APK Build Setup (বাংলা)

এই ZIP-এ Android প্রজেক্ট, Gradle Wrapper (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, `gradle/wrapper/gradle-wrapper.properties`) এবং GitHub Actions workflow আছে।

## কী পরিবর্তন করা হয়েছে
- Android SDK সেটআপে পুরোনো/অপ্রাপ্য `tools` প্যাকেজ বাদ দেওয়া হয়েছে।
- GitHub Actions এখন `./gradlew :app:assembleDebug` দিয়ে প্রজেক্টের নির্দিষ্ট Gradle Wrapper ব্যবহার করবে।
- অপ্রয়োজনীয় nested `gradle/gradle/` কপি সরানো হয়েছে।
- Build সফল হলে APK যাচাই করে artifact হিসেবে আপলোড করা হবে।

## APK তৈরি
ZIP extract করে প্রজেক্টের ভেতরের ফাইলগুলো GitHub repository-র root-এ রাখুন, তারপর `main` branch-এ push করুন অথবা Actions থেকে **Build and Release Debug APK** workflow-টি manually চালান। Workflow চালানোর সময় GitHub runner-কে ইন্টারনেট দিয়ে Gradle distribution ও Android dependencies ডাউনলোড করতে হবে।

**গুরুত্বপূর্ণ:** এই পরিবেশে নেটওয়ার্ক অ্যাক্সেস না থাকায় সম্পূর্ণ Android build চালিয়ে APK তৈরি/যাচাই করা সম্ভব হয়নি। তাই ZIP-এর workflow ও পরিচিত SDK setup সমস্যা ঠিক করা হয়েছে, কিন্তু সফল build-এর নিশ্চয়তা দেওয়া যাচ্ছে না; নতুন compile/dependency error দেখা দিলে তার log অনুযায়ী আলাদা সংশোধন লাগতে পারে।
