package com.livebangla.translator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var translated: TextView
    private lateinit var voiceButton: Button
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var voiceEnabled = true
    private var listening = false
    private var translator: com.google.mlkit.nl.translate.Translator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "এই ফোনে Speech Recognition service পাওয়া যায়নি।"
        }
        requestMicPermission()
        prepareTranslator("en")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        status = TextView(this).apply { text = "প্রস্তুত"; textSize = 17f }
        heard = TextView(this).apply { text = "শোনা কথা এখানে দেখাবে"; textSize = 18f; setPadding(0, 28, 0, 18) }
        translated = TextView(this).apply { text = "বাংলা অনুবাদ এখানে দেখাবে"; textSize = 23f; setPadding(0, 12, 0, 28) }
        val start = Button(this).apply {
            text = "মাইক্রোফোন চালু করুন"
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        voiceButton = Button(this).apply {
            text = "বাংলা কণ্ঠ: চালু"
            setOnClickListener {
                voiceEnabled = !voiceEnabled
                text = if (voiceEnabled) "বাংলা কণ্ঠ: চালু" else "বাংলা কণ্ঠ: বন্ধ"
                if (!voiceEnabled) tts?.stop()
            }
        }
        val note = TextView(this).apply {
            text = "\nনোট: এই প্রাথমিক সংস্করণ মাইক্রোফোনের শব্দ শুনে কাজ করে। PLAYit-এর ভেতরের অডিও সরাসরি ধরার সুবিধা এখনো যুক্ত করা হয়নি।"
            textSize = 14f
        }
        root.addView(status); root.addView(heard); root.addView(translated)
        root.addView(start); root.addView(voiceButton); root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
    }

    private fun prepareTranslator(source: String) {
        val sourceCode = when (source) {
            "hi" -> TranslateLanguage.HINDI
            else -> TranslateLanguage.ENGLISH
        }
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceCode)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        translator?.close()
        translator = Translation.getClient(options)
        status.text = "বাংলা অনুবাদ মডেল প্রস্তুত হচ্ছে…"
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { status.text = "প্রস্তুত — মাইক্রোফোন চালু করুন" }
            ?.addOnFailureListener { status.text = "অনুবাদ মডেল ডাউনলোড হয়নি: ইন্টারনেট পরীক্ষা করুন" }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech Recognition service অনুপলব্ধ"; return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "শুনছি…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "অনুবাদ করছি…" }
            override fun onError(error: Int) { status.text = "শোনা বন্ধ হয়েছে। আবার চালু করুন।"; listening = false }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) translate(text)
                listening = false
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) heard.text = "শোনা হচ্ছে: $text"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        listening = true
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        recognizer?.stopListening()
        recognizer?.cancel()
        listening = false
        status.text = "বন্ধ"
    }

    private fun translate(text: String) {
        heard.text = "মূল কথা: $text"
        val client = translator ?: return
        status.text = "বাংলায় অনুবাদ হচ্ছে…"
        client.translate(text)
            .addOnSuccessListener { result ->
                translated.text = result
                status.text = "অনুবাদ সম্পন্ন"
                if (voiceEnabled) tts?.speak(result, TextToSpeech.QUEUE_FLUSH, null, "bn_translation")
            }
            .addOnFailureListener { status.text = "অনুবাদ ব্যর্থ হয়েছে" }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                status.text = "এই ফোনে বাংলা TTS voice ইনস্টল/সমর্থিত নয়"
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        translator?.close()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
