# Live Bangla Translator (starter project)

Android starter project targeting Android 15 (API 35).

## Current prototype
- Microphone-based speech recognition through Android's installed recognition service.
- English-to-Bengali translation using ML Kit (model downloads on first use; afterward can work offline).
- Bengali text-to-speech using the device's installed Bengali voice, if available.
- Hindi is listed as a future source option; the current prototype is English-only.

## Important limitations
This is NOT yet a complete PLAYit live-audio translator. Android's microphone recognition hears nearby speaker audio and may be delayed/noisy. Direct capture of another app's playback requires MediaProjection + AudioPlaybackCapture and the source player must permit capture. PLAYit compatibility is not guaranteed.
The current prototype does not yet include Hindi auto-detection, floating overlay captions, audio ducking, or offline speech recognition. Those are later development steps.

## Build
Open this project in Android Studio, or use the included GitHub Actions workflow.
The workflow runs `gradle :app:assembleDebug` on GitHub-hosted Ubuntu and uploads the APK as an Actions artifact.
